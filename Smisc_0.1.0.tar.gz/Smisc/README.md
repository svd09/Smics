# Smisc
This contains miscellaneous functions in R for everyday computing 

The package can be installed from here.

install.packages("devtools") 

devtools::install_github("svd09/Smisc")
